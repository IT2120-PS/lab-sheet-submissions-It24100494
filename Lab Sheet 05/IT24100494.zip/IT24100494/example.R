##lab
getwd()
setwd("//Users//shashinisilva//Desktop//IT24100494")
getwd()
data<-read.table("Data.txt",header=TRUE,sep=",")
fix(data)
attach(data)

##part 1

names(data)<-c("X1","X2")
attach(data)
hist(X2,main="Histogram for number of shareholders")

##part 2

histogram<-hist(X2,main="Histogram for number of shareholder",breaks = seq(130, 270,length=8),right=FALSE)
?hist

##part 3
breaks<-round(histogram$breaks)
freq<-histogram$counts
mids<-histogram$mids
classes<-c()
for(i in 1:length(breaks)-1){
  classes[i]<-pasteO("[",breaks[i],",",breaks[i+1],")") 
}
  
   